import time, json
from kafka import KafkaProducer
from hdfs import InsecureClient

hdfs_client = InsecureClient('http://localhost:9870', user='user')
producer = KafkaProducer(
    bootstrap_servers='127.0.0.1:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
    api_version=(3, 9, 1),
    request_timeout_ms=30000
)

with hdfs_client.read('/project/rawdata/tweets.csv', encoding='latin-1') as reader:
    for i, line in enumerate(reader):
        parts = line.strip().split(',', 5)
        if len(parts) < 6:
            continue
        record = {
            "target": parts[0], "id": parts[1], "date": parts[2],
            "flag": parts[3], "user": parts[4], "text": parts[5]
        }
        producer.send('tweets-stream', value=record)
        if i % 500 == 0:
            print(f"Sent {i} records")
            time.sleep(0.5)

producer.flush()