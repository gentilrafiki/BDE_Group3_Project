from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when
from pyspark.ml.feature import RegexTokenizer, StopWordsRemover, HashingTF, IDF
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# 1. Start Spark and read the dataset from HDFS (not local disk)
spark = SparkSession.builder.appName("SentimentTraining").getOrCreate()

df = spark.read.csv("hdfs://localhost:9000/project/rawdata/tweets.csv", header=False, inferSchema=True)
df = df.toDF("target", "id", "date", "flag", "user", "text")
df = df.repartition(4)

# 2. Convert Sentiment140's labels (0=negative, 4=positive) into a clean 0/1 label
df = df.withColumn("label", when(col("target") == 4, 1.0).otherwise(0.0))
df = df.dropna(subset=["text"])

print(f"Total rows loaded from HDFS: {df.count()}")

# 3. Break tweets into words, then strip common filler words
tokenizer = RegexTokenizer(inputCol="text", outputCol="words", pattern="\\W")
remover = StopWordsRemover(inputCol="words", outputCol="filtered")

# 4. Convert words into numeric vectors (TF-IDF: term frequency, inverse document frequency)
hashingTF = HashingTF(inputCol="filtered", outputCol="rawFeatures", numFeatures=2000)
idf = IDF(inputCol="rawFeatures", outputCol="features")

# 5. The actual classifier
lr = LogisticRegression(featuresCol="features", labelCol="label", maxIter=20)

# 6. Chain all steps into one pipeline
pipeline = Pipeline(stages=[tokenizer, remover, hashingTF, idf, lr])

# 7. Split data: 80% to train on, 20% held back to test accuracy honestly
train, test = df.randomSplit([0.8, 0.2], seed=42)

print("Training model... this will take a few minutes on 8 million rows.")
model = pipeline.fit(train)

# 8. Test the trained model on data it has never seen
predictions = model.transform(test)
evaluator = MulticlassClassificationEvaluator(labelCol="label", metricName="accuracy")
accuracy = evaluator.evaluate(predictions)
print(f"TEST ACCURACY: {accuracy:.4f}")

# 9. Save the trained model back to HDFS so the streaming job can reuse it later
model.write().overwrite().save("hdfs://localhost:9000/project/model/sentiment_lr")
print("Model saved to HDFS at /project/model/sentiment_lr")

spark.stop()