from django.shortcuts import render
from .models import Prediction

def home(request):
    total = Prediction.objects.count()
    positive = Prediction.objects.filter(predicted_sentiment=1.0).count()
    negative = Prediction.objects.filter(predicted_sentiment=0.0).count()
    recent = Prediction.objects.all()[:20]
    return render(request, 'dashboard/home.html', {
        'total': total, 'positive': positive, 'negative': negative, 'recent': recent
    })