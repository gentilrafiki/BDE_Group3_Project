from django.db import models

# Create your models here.
from django.db import models

class Prediction(models.Model):
    id = models.CharField(max_length=50, primary_key=True)
    user = models.CharField(max_length=100, db_column='user')
    text = models.TextField()
    date = models.CharField(max_length=50)
    predicted_sentiment = models.FloatField()

    class Meta:
        managed = False
        db_table = 'predictions'
