from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType
from pyspark.ml import PipelineModel

spark = SparkSession.builder.appName("SentimentStreaming").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# 1. Load the already-trained model from HDFS (no retraining happens here)
model = PipelineModel.load("hdfs://localhost:9000/project/model/sentiment_lr")

# 2. Define the shape of incoming Kafka messages (matches producer.py's JSON structure)
schema = StructType() \
    .add("target", StringType()).add("id", StringType()).add("date", StringType()) \
    .add("flag", StringType()).add("user", StringType()).add("text", StringType())

# 3. Read the live stream from Kafka
raw = spark.readStream.format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("subscribe", "tweets-stream") \
    .option("startingOffsets", "latest") \
    .load()

# 4. Parse the JSON and apply the trained model to each incoming tweet
parsed = raw.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")
predictions = model.transform(parsed).select(
    "id", "user", "text", "date", col("prediction").alias("predicted_sentiment")
)

# 5. RDS connection details
DB_URL = "jdbc:mysql://sentiment-db.cg1qoq222ze0.us-east-1.rds.amazonaws.com:3306/sentiment_db?rewriteBatchedStatements=true"
DB_USER = "admin"
DB_PASSWORD = "YOUR_PASSWORD"
DB_TABLE = "predictions"

# 6. For each micro-batch of predictions, write them into RDS
def write_to_mysql(batch_df, batch_id):
    batch_df.write.format("jdbc") \
        .option("url", DB_URL).option("dbtable", DB_TABLE) \
        .option("user", DB_USER).option("password", DB_PASSWORD) \
        .option("driver", "com.mysql.cj.jdbc.Driver") \
        .option("batchsize", "1000") \
        .mode("append").save()
    print(f"Batch {batch_id}: wrote {batch_df.count()} rows")

query = predictions.writeStream.foreachBatch(write_to_mysql).outputMode("append").start()
query.awaitTermination()