import pandas as pd

cols = ['target', 'id', 'date', 'flag', 'user', 'text']
df = pd.read_csv('training.1600000.processed.noemoticon.csv', encoding='latin-1', names=cols)

print(f"Original rows: {len(df)}")

frames = []
for i in range(5):
    copy = df.copy()
    copy['id'] = copy['id'].astype(str) + f"_{i}"
    frames.append(copy)

big_df = pd.concat(frames, ignore_index=True)
big_df.to_csv('tweets.csv', index=False)
print(f"Scaled rows: {len(big_df)}")