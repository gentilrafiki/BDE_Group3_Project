Run order:
1. scale_dataset.py   - builds the 1GB dataset from Sentiment140
2. train_model.py     - trains the MLlib model from HDFS
3. producer.py        - streams tweets into Kafka
4. stream_consumer.py - Spark reads Kafka, predicts, writes to AWS RDS
5. python manage.py runserver - starts the Django dashboard

Note: tweets.csv (1.1GB) is not included due to size.
Database password replaced with YOUR_PASSWORD.